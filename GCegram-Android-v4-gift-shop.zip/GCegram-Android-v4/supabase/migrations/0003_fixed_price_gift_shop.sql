-- Run after the previous GCegram migrations.
create or replace function public.purchase_gift(p_gift_id uuid)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare
  buyer uuid := auth.uid();
  item public.gifts_catalog%rowtype;
  buyer_profile public.profiles%rowtype;
  gift_instance uuid;
begin
  if buyer is null then raise exception 'Нужно войти в аккаунт.'; end if;
  select * into item from public.gifts_catalog
    where id=p_gift_id and is_active=true for share;
  if not found then raise exception 'Подарок больше не продаётся.'; end if;
  select * into buyer_profile from public.profiles where id=buyer for update;
  if not found then raise exception 'Профиль не найден.'; end if;
  if buyer_profile.stars < item.base_price then raise exception 'Недостаточно звёзд.'; end if;
  update public.profiles set stars=stars-item.base_price where id=buyer;
  insert into public.user_gifts(gift_id,owner_id) values(item.id,buyer)
    returning id into gift_instance;
  insert into public.gift_transfers(gift_instance_id,from_user,to_user,transfer_type,stars_amount)
    values(gift_instance,buyer,buyer,'sale',item.base_price);
  return jsonb_build_object('gift_instance_id',gift_instance,'gift_name',item.name,'price',item.base_price);
end;
$$;
revoke all on function public.purchase_gift(uuid) from public;
grant execute on function public.purchase_gift(uuid) to authenticated;
