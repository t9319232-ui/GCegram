-- Run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Пользователь',
  username text not null unique check (username ~ '^[a-z0-9_]{3,20}$'),
  stars bigint not null default 0 check (stars >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.user_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('owner','user'))
);

create table if not exists public.rooms (
  id uuid primary key,
  name text not null,
  created_at timestamptz not null default now()
);
insert into public.rooms(id,name) values ('00000000-0000-0000-0000-000000000001','general') on conflict do nothing;

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.rooms enable row level security;
alter table public.messages enable row level security;

create policy "profiles readable by signed in users" on public.profiles for select to authenticated using (true);
create policy "user can update own basic profile" on public.profiles for update to authenticated using (auth.uid()=id) with check (auth.uid()=id);
create policy "roles readable by self" on public.user_roles for select to authenticated using (auth.uid()=user_id);
create policy "rooms readable by signed in users" on public.rooms for select to authenticated using (true);
create policy "messages readable by signed in users" on public.messages for select to authenticated using (true);
create policy "users send as themselves" on public.messages for insert to authenticated with check (auth.uid()=sender_id);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$
declare clean_username text;
begin
  clean_username := lower(coalesce(new.raw_user_meta_data->>'username','user_'||substr(new.id::text,1,8)));
  insert into public.profiles(id,display_name,username)
  values(new.id,coalesce(nullif(new.raw_user_meta_data->>'display_name',''),'Пользователь'),clean_username);
  insert into public.user_roles(user_id,role) values(new.id,'user');
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

-- Owner setup: after registering your own account, run this query with YOUR account UUID.
-- Find UUID in Authentication -> Users. Never make this public or give owner role to strangers.
-- update public.user_roles set role='owner' where user_id='YOUR-USER-UUID';
