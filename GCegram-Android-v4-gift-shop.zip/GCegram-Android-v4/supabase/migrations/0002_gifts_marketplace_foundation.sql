-- GCegram gifts marketplace foundation.
-- Run AFTER 0001_gcegram.sql in Supabase SQL Editor.
create table if not exists public.gifts_catalog (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text not null default '',
  image_url text,
  base_price bigint not null check (base_price > 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.user_gifts (
  id uuid primary key default gen_random_uuid(),
  gift_id uuid not null references public.gifts_catalog(id),
  owner_id uuid not null references public.profiles(id),
  acquired_from uuid references public.user_gifts(id),
  created_at timestamptz not null default now()
);

create table if not exists public.gift_transfers (
  id uuid primary key default gen_random_uuid(),
  gift_instance_id uuid not null references public.user_gifts(id),
  from_user uuid not null references public.profiles(id),
  to_user uuid not null references public.profiles(id),
  transfer_type text not null check (transfer_type in ('gift','sale','trade','redeem')),
  stars_amount bigint not null default 0 check (stars_amount >= 0),
  created_at timestamptz not null default now()
);

alter table public.gifts_catalog enable row level security;
alter table public.user_gifts enable row level security;
alter table public.gift_transfers enable row level security;

create policy "catalog visible to signed in users"
on public.gifts_catalog for select to authenticated using (is_active = true);

create policy "users can view their own gifts"
on public.user_gifts for select to authenticated using (owner_id = auth.uid());

create policy "users can view transfers involving them"
on public.gift_transfers for select to authenticated
using (from_user = auth.uid() or to_user = auth.uid());

-- IMPORTANT:
-- Gift purchase, transfer, resale, exchange and redeem actions must be implemented
-- as SECURITY DEFINER database functions or server-side Edge Functions with
-- row locks and balance checks. Do NOT let clients directly update stars or owner_id.
-- This starter intentionally does not expose unsafe client-side write policies.
