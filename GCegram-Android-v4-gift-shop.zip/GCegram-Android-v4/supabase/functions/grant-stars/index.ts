import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

Deno.serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });
  const authHeader = req.headers.get('Authorization');
  if (!authHeader) return Response.json({ error: 'Unauthorized' }, { status: 401 });

  const url = Deno.env.get('SUPABASE_URL')!;
  const anon = Deno.env.get('SUPABASE_ANON_KEY')!;
  const service = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const userClient = createClient(url, anon, { global: { headers: { Authorization: authHeader } } });
  const adminClient = createClient(url, service);

  const { data: { user }, error: userError } = await userClient.auth.getUser();
  if (userError || !user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

  const { data: role } = await adminClient.from('user_roles').select('role').eq('user_id', user.id).maybeSingle();
  if (role?.role !== 'owner') return Response.json({ error: 'Только владелец может выдавать звёзды.' }, { status: 403 });

  const { username, amount } = await req.json();
  const clean = String(username || '').replace(/^@/, '').toLowerCase();
  const count = Number(amount);
  if (!/^[a-z0-9_]{3,20}$/.test(clean) || !Number.isInteger(count) || count < 1 || count > 100000) {
    return Response.json({ error: 'Проверь юзернейм и количество звёзд.' }, { status: 400 });
  }

  const { data: target, error: findError } = await adminClient.from('profiles').select('id,username,stars').eq('username', clean).maybeSingle();
  if (findError || !target) return Response.json({ error: 'Пользователь не найден.' }, { status: 404 });

  const { error: updateError } = await adminClient.from('profiles').update({ stars: target.stars + count }).eq('id', target.id);
  if (updateError) return Response.json({ error: 'Не удалось начислить звёзды.' }, { status: 500 });
  return Response.json({ message: `Начислено ${count} ⭐ пользователю @${clean}.` });
});
