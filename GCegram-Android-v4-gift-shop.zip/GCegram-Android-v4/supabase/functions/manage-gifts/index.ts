import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
Deno.serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed', {status:405});
  const authHeader=req.headers.get('Authorization');
  if (!authHeader) return Response.json({error:'Unauthorized'},{status:401});
  const url=Deno.env.get('SUPABASE_URL')!;
  const admin=createClient(url,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  const userClient=createClient(url,Deno.env.get('SUPABASE_ANON_KEY')!,{global:{headers:{Authorization:authHeader}}});
  const {data:{user},error}=await userClient.auth.getUser();
  if(error||!user) return Response.json({error:'Unauthorized'},{status:401});
  const {data:role}=await admin.from('user_roles').select('role').eq('user_id',user.id).maybeSingle();
  if(role?.role!=='owner') return Response.json({error:'Только владелец может добавлять подарки.'},{status:403});
  const body=await req.json();
  const name=String(body.name||'').trim(), description=String(body.description||'').trim();
  const image_url=body.image_url?String(body.image_url).trim():null, base_price=Number(body.base_price);
  if(!name||name.length>60||description.length>240||!Number.isSafeInteger(base_price)||base_price<1||base_price>100000000||(image_url&&!/^https:\/\/.+/i.test(image_url)))
    return Response.json({error:'Проверь название, описание, HTTPS-ссылку и цену.'},{status:400});
  const {data,error:insertError}=await admin.from('gifts_catalog').insert({name,description,image_url,base_price,is_active:true}).select('id,name,description,image_url,base_price').single();
  if(insertError) return Response.json({error:insertError.message},{status:400});
  return Response.json({message:`Подарок «${name}» добавлен в магазин.`,gift:data});
});
