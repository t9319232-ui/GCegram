import { createClient } from '@supabase/supabase-js';
import './style.css';

const url = import.meta.env.VITE_SUPABASE_URL;
const anon = import.meta.env.VITE_SUPABASE_ANON_KEY;
const app = document.querySelector('#app');
let supabase = null, currentUser = null, profile = null, activeRoom = 'general', channel = null;

const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function shell(title, body){ app.innerHTML = `<div class="wrap"><header><div class="logo">GC</div><div><b>GCegram</b><small>${title}</small></div><span class="spacer"></span><span class="stars" id="balance">⭐ —</span></header>${body}</div>`; }
function configScreen(){
 shell('Настройка подключения', `<section class="card"><h1>Подключи базу данных</h1><p>Вставь URL проекта Supabase и публичный anon key в файл <code>.env</code>. Не вставляй сюда пароль от почты, service role key или секреты.</p><p>Затем перезапусти приложение командой <code>npm run dev</code>.</p></section>`);
}
function authScreen(mode='register', error=''){
 const registering = mode==='register';
 shell(registering?'Создание аккаунта':'Вход в аккаунт', `<section class="auth card"><div class="tabs"><button id="regTab" class="${registering?'selected':''}">Регистрация</button><button id="loginTab" class="${!registering?'selected':''}">Вход</button></div>
 <h1>${registering?'Создать аккаунт':'С возвращением!'}</h1><p class="muted">${registering?'Заполни данные, чтобы присоединиться к GCegram.':'Войди по почте и паролю.'}</p>
 <form id="authForm">
 ${registering?`<label>Имя<input name="displayName" placeholder="Например, Алекс" maxlength="40" required></label><label>Юзернейм<input name="username" placeholder="Например, alex123" minlength="3" maxlength="20" pattern="[A-Za-z0-9_]+" required><small>Только латинские буквы, цифры и _</small></label>`:''}
 <label>Почта<input name="email" type="email" autocomplete="email" placeholder="name@example.com" required></label>
 <label>Пароль<input name="password" type="password" minlength="8" autocomplete="${registering?'new-password':'current-password'}" placeholder="Минимум 8 символов" required></label>
 ${registering?'<label>Пароль (повторение)<input name="confirm" type="password" minlength="8" autocomplete="new-password" required></label>':''}
 <button class="primary" type="submit">${registering?'Зарегистрироваться':'Войти'}</button></form><p class="error">${esc(error)}</p><p class="fine">Не используй пароль от других важных аккаунтов.</p></section>`);
 document.querySelector('#regTab').onclick=()=>authScreen('register');
 document.querySelector('#loginTab').onclick=()=>authScreen('login');
 document.querySelector('#authForm').onsubmit=async e=>{
  e.preventDefault(); const f=new FormData(e.target), email=String(f.get('email')).trim(), password=String(f.get('password'));
  if(registering){
   if(password!==f.get('confirm')) return authScreen('register','Пароли не совпадают.');
   const username=String(f.get('username')).trim().toLowerCase();
   if(!/^[a-z0-9_]{3,20}$/.test(username)) return authScreen('register','Проверь юзернейм.');
   const {data,error}=await supabase.auth.signUp({email,password,options:{data:{display_name:String(f.get('displayName')).trim(),username}}});
   if(error) return authScreen('register',error.message);
   if(data.session) await loadApp(); else authScreen('login','Аккаунт создан. Если включено подтверждение почты, проверь входящие письма.');
  }else{
   const {error}=await supabase.auth.signInWithPassword({email,password});
   if(error) return authScreen('login',error.message);
   await loadApp();
  }
 };
}
async function loadApp(){
 const {data:{user}}=await supabase.auth.getUser(); currentUser=user;
 if(!user){authScreen();return;}
 let res=await supabase.from('profiles').select('*').eq('id',user.id).single();
 if(res.error){shell('Загрузка профиля',`<section class="card"><p>${esc(res.error.message)}</p><button id="retry" class="primary">Повторить</button></section>`);document.querySelector('#retry').onclick=loadApp;return;}
 profile=res.data;
 const {data:role}=await supabase.from('user_roles').select('role').eq('user_id',user.id).maybeSingle();
 const isOwner=role?.role==='owner';
 shell('Мессенджер', `<nav><button class="selected" data-page="chat">💬 Чаты</button><button data-page="shop">🎁 Магазин</button><button data-page="mygifts">🎒 Мои подарки</button><button data-page="stars">⭐ Звёзды</button><button data-page="profile">👤 Профиль</button>${isOwner?'<button data-page="admin">👑 Владелец</button>':''}<button id="logout">Выйти</button></nav><main id="content"></main>`);
 document.querySelector('#logout').onclick=async()=>{if(channel)await supabase.removeChannel(channel);await supabase.auth.signOut();authScreen('login')};
 document.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-page]').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');if(channel){supabase.removeChannel(channel);channel=null;}showPage(b.dataset.page,isOwner)});
 showPage('chat',isOwner); loadBalance();
}
async function loadBalance(){const {data}=await supabase.from('profiles').select('stars').eq('id',currentUser.id).single();document.querySelector('#balance').textContent=`⭐ ${data?.stars??0}`;}
async function showPage(page,isOwner){
 const c=document.querySelector('#content');
 if(page==='chat'){
  c.innerHTML=`<section class="card"><div class="row"><div><h2># general</h2><small>Общий чат GCegram</small></div></div><div id="msgs" class="msgs"></div><form id="send" class="send"><input name="body" maxlength="2000" placeholder="Написать сообщение…" required><button class="primary">➤</button></form></section>`;
  await loadMessages();
  channel=supabase.channel('public-chat').on('postgres_changes',{event:'INSERT',schema:'public',table:'messages',filter:'room_id=eq.00000000-0000-0000-0000-000000000001'},()=>loadMessages()).subscribe();
  document.querySelector('#send').onsubmit=async e=>{e.preventDefault();const body=new FormData(e.target).get('body').trim();if(!body)return;const {error}=await supabase.from('messages').insert({room_id:'00000000-0000-0000-0000-000000000001',sender_id:currentUser.id,body});if(error)alert(error.message);else e.target.reset();};
 }else if(page==='shop'){
  const {data:items,error}=await supabase.from('gifts_catalog').select('id,name,description,image_url,base_price').eq('is_active',true).order('created_at',{ascending:false});
  c.innerHTML=`<section class="card"><h2>🎁 Магазин подарков</h2><p class="muted">Коллекционные подарки GCegram с фиксированной ценой.</p>${error?`<p class="error">${esc(error.message)}</p>`:(items||[]).length?`<div class="gift-grid">${items.map(g=>`<article class="gift-card">${g.image_url?`<img src="${esc(g.image_url)}" alt="">`:`<div class="gift-placeholder">🎁</div>`}<h3>${esc(g.name)}</h3><p>${esc(g.description)}</p><b>⭐ ${g.base_price}</b><button class="primary buy-gift" data-id="${g.id}">Купить</button></article>`).join('')}</div>`:'<p class="muted">Пока подарков нет.</p>'}</section>`;
  c.querySelectorAll('.buy-gift').forEach(b=>b.onclick=async()=>{b.disabled=true;const {data,error}=await supabase.rpc('purchase_gift',{p_gift_id:b.dataset.id});if(error){alert(error.message);b.disabled=false;}else{alert(`Подарок «${data.gift_name}» куплен!`);loadBalance();showPage('mygifts',isOwner);}});
 }else if(page==='mygifts'){
  const {data,error}=await supabase.from('user_gifts').select('id,created_at,gifts_catalog(name,description,image_url)').eq('owner_id',currentUser.id).order('created_at',{ascending:false});
  c.innerHTML=`<section class="card"><h2>🎒 Мои подарки</h2>${error?`<p class="error">${esc(error.message)}</p>`:(data||[]).length?`<div class="gift-grid">${data.map(x=>`<article class="gift-card">${x.gifts_catalog?.image_url?`<img src="${esc(x.gifts_catalog.image_url)}" alt="">`:`<div class="gift-placeholder">🎁</div>`}<h3>${esc(x.gifts_catalog?.name||'Подарок')}</h3><p>${esc(x.gifts_catalog?.description||'')}</p></article>`).join('')}</div>`:'<p class="muted">Подарков пока нет. Загляни в магазин!</p>'}</section>`;
 }else if(page==='stars'){
  const {data}=await supabase.from('profiles').select('stars').eq('id',currentUser.id).single();
  c.innerHTML=`<section class="card"><h1>⭐ ${data?.stars??0}</h1><h2>Твои звёзды</h2><p class="muted">Это внутренняя виртуальная валюта GCegram. Она не является Telegram Stars и не имеет денежной стоимости.</p></section>`;
 }else if(page==='profile'){
  c.innerHTML=`<section class="card"><h2>Профиль</h2><p><b>Имя:</b> ${esc(profile.display_name)}</p><p><b>Юзернейм:</b> @${esc(profile.username)}</p><p><b>Почта:</b> ${esc(currentUser.email)}</p></section>`;
 }else if(page==='admin'&&isOwner){
  c.innerHTML=`<section class="card"><h2>👑 Панель владельца</h2><h3>Добавить подарок в продажу</h3><p class="muted">Задай название, изображение и фиксированную цену в звёздах.</p><form id="addGift"><label>Название<input name="name" maxlength="60" required></label><label>Описание<input name="description" maxlength="240"></label><label>Ссылка на картинку (HTTPS)<input name="image_url" type="url" placeholder="https://..."></label><label>Фиксированная цена ⭐<input name="base_price" type="number" min="1" max="100000000" value="100" required></label><button class="primary">Опубликовать в магазине</button></form><p id="giftResult" class="muted"></p><hr><h3>Начислить звёзды</h3><form id="grant"><label>Юзернейм<input name="username" placeholder="alex123" required></label><label>Количество звёзд<input name="amount" type="number" min="1" max="100000" value="50" required></label><button class="primary">Начислить ⭐</button></form><p id="grantResult" class="muted"></p></section>`;
  document.querySelector('#addGift').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);const {data,error}=await supabase.functions.invoke('manage-gifts',{body:{name:String(f.get('name')),description:String(f.get('description')||''),image_url:String(f.get('image_url')||'')||null,base_price:Number(f.get('base_price'))}});document.querySelector('#giftResult').textContent=error?error.message:(data?.message||'Готово');if(!error)e.target.reset();};
  document.querySelector('#grant').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);const {data,error}=await supabase.functions.invoke('grant-stars',{body:{username:String(f.get('username')).replace(/^@/,''),amount:Number(f.get('amount'))}});document.querySelector('#grantResult').textContent=error?error.message:(data?.message||'Готово');};
 }
}
async function loadMessages(){
 const {data,error}=await supabase.from('messages').select('id,body,created_at,sender_id,profiles(username,display_name)').eq('room_id','00000000-0000-0000-0000-000000000001').order('created_at',{ascending:true}).limit(100);
 const box=document.querySelector('#msgs');if(!box)return;
 if(error){box.textContent=error.message;return;}
 box.innerHTML=(data||[]).map(m=>`<div class="msg ${m.sender_id===currentUser.id?'mine':''}"><b>${esc(m.profiles?.display_name||m.profiles?.username||'Пользователь')}</b><div>${esc(m.body)}</div><small>${new Date(m.created_at).toLocaleString()}</small></div>`).join('');
 box.scrollTop=box.scrollHeight;
}
if(!url||!anon||url.includes('YOUR-PROJECT')) configScreen();
else {supabase=createClient(url,anon);supabase.auth.getSession().then(({data})=>data.session?loadApp():authScreen());supabase.auth.onAuthStateChange((_event,session)=>{if(session&&!currentUser)loadApp();});}
